package com.example.scsystem.demos.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.scsystem.demos.domin.Commodity;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface CommodityMapper extends BaseMapper<Commodity> {
}
