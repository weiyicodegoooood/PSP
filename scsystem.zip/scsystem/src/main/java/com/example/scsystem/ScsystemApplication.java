package com.example.scsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScsystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(ScsystemApplication.class, args);
    }

}
