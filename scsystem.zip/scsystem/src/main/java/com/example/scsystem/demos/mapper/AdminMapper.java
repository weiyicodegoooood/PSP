package com.example.scsystem.demos.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.scsystem.demos.domin.Admin;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface AdminMapper extends BaseMapper<Admin> {

    @Update("UPDATE user SET Password = #{pwd} WHERE id = #{id}" )
    int updatePwd(@Param("pwd") String pwd, @Param("id") Integer id);

}
