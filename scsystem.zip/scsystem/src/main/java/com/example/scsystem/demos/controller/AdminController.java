package com.example.scsystem.demos.controller;

import com.example.scsystem.demos.Aop.Aop;
import com.example.scsystem.demos.Utils.Result;
import com.example.scsystem.demos.domin.Admin;
import com.example.scsystem.demos.domin.Commodity;
import com.example.scsystem.demos.domin.User;
import com.example.scsystem.demos.service.AdminService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "管理员模块")
@Component
@RestController
@CrossOrigin
@ResponseBody
public class AdminController {

    @Autowired
    private AdminService adminService;

    @ApiOperation("管理员登录")
    @RequestMapping("/adminlogin")
    @Aop(module = "管理员模块",operator = "管理员登录")
    public Result login(@RequestBody Admin admin)
    {
        return adminService.login(admin.getName(),admin.getPassword());
    }

    @ApiOperation("根据名字查询用户")
    @RequestMapping("/getbyuser/{name}")
    @Aop(module = "管理员模块",operator = "查询用户")
    public Result GetByUser(@PathVariable String name)
    {
        return adminService.GetByUser(name);
    }
    @ApiOperation("根据名字查询商品")
    @RequestMapping("/getbycom/{name}")
    @Aop(module = "管理员模块",operator = "查询商品")
    public Result GetByCom(@PathVariable String name)
    {
        return adminService.GetByCom(name);
    }

    @ApiOperation("添加用户")
    @RequestMapping("/insertuser")
    @Aop(module = "管理员模块",operator = "添加用户")
    public Result InsertUser(@RequestBody User user)
    {
        return adminService.InsertUser(user);
    }

    @ApiOperation("添加商品")
    @RequestMapping("/insertcom")
    @Aop(module = "管理员模块",operator = "添加商品")
    public Result InsertCom(@RequestBody Commodity commodity)
    {
        return adminService.InsertCom(commodity);
    }

    @ApiOperation("删除用户")
    @RequestMapping("/deleteuser/{name}")
    @Aop(module = "管理员模块",operator = "删除用户")
    public Result DeleteUser(@PathVariable String name)
    {
        return adminService.DeleteUser(name);
    }

    @ApiOperation("删除商品")
    @RequestMapping("/deletecom/{id}")
    @Aop(module = "管理员模块",operator = "删除商品")
    public Result DeleteUser(@PathVariable int id)
    {
        return adminService.DeleteCom(id);
    }

    @ApiOperation("更改用户信息")
    @RequestMapping("/update/{id}/{password}")
    @Aop(module = "管理员模块",operator = "更新用户信息")
    public Result UpdateUser(@PathVariable("id") int id, @PathVariable("password") String password)
    {
        return adminService.updateUser(id,password);
    }

    @ApiOperation("查看所有用户")
    @RequestMapping("/getallusers")
    @Aop(module = "管理员模块",operator = "查看所有用户")
    public Result GetAllUsers()
    {
        List<User> users = adminService.GetAllUsers();

        return Result.success(users);
    }

    @ApiOperation("查看所有商品")
    @RequestMapping("/getallcom")
    @Aop(module = "管理员模块",operator = "查看所有商品")
    public Result GetAllCom()
    {
        List<Commodity> coms = adminService.GetAllCom();

        return Result.success(coms);
    }











}
