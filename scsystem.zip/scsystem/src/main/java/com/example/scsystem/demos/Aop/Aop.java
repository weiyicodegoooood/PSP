package com.example.scsystem.demos.Aop;


import java.lang.annotation.*;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Aop {

    String module() default "";

    String operator() default "";
}
