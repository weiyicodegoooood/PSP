package com.example.scsystem.demos.domin;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.springframework.stereotype.Component;

@Data
@NoArgsConstructor  //空参构造方法
@AllArgsConstructor //全参构造方法
@Component
@Accessors(chain = true)
@TableName("commodity")
@ApiModel(value = "commodity对象",description = "商品信息")
public class Commodity {


    @TableField(value = "ID")
//    @TableId(type = IdType.AUTO)
    @ApiModelProperty(value = "商品id")
    private Integer id;

    @TableField(value = "Picture")
    @ApiModelProperty(value = "商品图片")
    private String picture;

    @TableField(value = "Cname")
    @ApiModelProperty(value = "商品名称")
    private String name;

    @TableField(value = "Des")
    @ApiModelProperty(value = "商品描述")
    private String des;

    @TableField(value = "Price")
    @ApiModelProperty(value = "商品价格")
    private String price;

    @TableField(value = "Model")
    @ApiModelProperty(value = "商品规格")
    private String model;

    @TableField(value = "State")
    @ApiModelProperty(value = "是否加入购物车(1:加入;0:不加入)")
    private String state;
}
