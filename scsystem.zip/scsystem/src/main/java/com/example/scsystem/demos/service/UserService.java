package com.example.scsystem.demos.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.example.scsystem.demos.Utils.Result;
import com.example.scsystem.demos.domin.User;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;

@Service
@Transactional
public interface UserService extends IService<User> {
    Result login(String Name,String Password);


    Result register(User user);

    Result logout(HttpServletRequest req);


    Result ChangeP(String Name,String Password);

}
