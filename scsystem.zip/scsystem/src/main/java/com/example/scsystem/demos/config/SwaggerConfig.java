package com.example.scsystem.demos.config;


import com.google.common.base.Predicates;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.ArrayList;

@Configuration //配置类
@EnableSwagger2// 开启Swagger2的自动配置
@EnableWebMvc
public class SwaggerConfig {

    @Bean
    public Docket webApiConfig() {
        Docket docket = new Docket(DocumentationType.SWAGGER_2)
                .groupName("webApi")
                .apiInfo(apiInfo())
                .select()
//                .paths(Predicates.and(PathSelectors.regex("/api/.*")))
                .build();
        return docket;
    }

    private ApiInfo apiInfo() {
        Contact contact = new Contact("**", "184375****@qq.com", "184375****@qq.com");
        return new ApiInfo(
                "校园集市管理系统后端接口文档Swagger", // 标题
                "校园集市系统后端接口", // 描述
                "v1.0", // 版本
                "184375****@qq.com", // 组织链接
                contact, // 联系人信息
                "Apach 2.0 许可", // 许可
                "许可链接", // 许可连接
                new ArrayList<>()// 扩展
        );
    }
}
