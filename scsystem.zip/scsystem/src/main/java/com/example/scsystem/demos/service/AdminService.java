package com.example.scsystem.demos.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.scsystem.demos.Utils.Result;
import com.example.scsystem.demos.domin.Admin;
import com.example.scsystem.demos.domin.Commodity;
import com.example.scsystem.demos.domin.User;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public interface AdminService extends IService<Admin> {

    Result login(String Name,String Password);

    Result GetByUser(String Name);

    Result GetByCom(String name);

    Result InsertUser(User user);

    Result InsertCom(Commodity commodity);

    Result DeleteUser(String Name);

    Result DeleteCom(Integer id);

    Result updateUser(int id,String password);

    List<User> GetAllUsers();

    List<Commodity> GetAllCom();
}
