package com.example.scsystem.demos.controller;


import com.example.scsystem.demos.Aop.Aop;
import com.example.scsystem.demos.Utils.Result;
import com.example.scsystem.demos.domin.User;
import com.example.scsystem.demos.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@Api(tags = "用户模块")
@Component
@RestController
@CrossOrigin
@ResponseBody
public class UserController {

    @Autowired
    private UserService userService;


    @ApiOperation("用户登录")
    @RequestMapping("/login")
    @Aop(module = "用户模块",operator = "用户登录")
    public Result login(@RequestBody User user)
    {
        return userService.login(user.getUname(),user.getPassword());
    }


    @ApiOperation("用户注册")
    @RequestMapping("/register")
    @Aop(module = "用户模块",operator = "用户注册")
    public Result register(@RequestBody User user)
    {
        return userService.register(user);
    }

    @ApiOperation("用户注销")
    @RequestMapping("/logout")
    @Aop(module = "用户模块",operator = "用户注销")
    public Result logout(HttpServletRequest req)
    {
        return userService.logout(req);
    }


    @ApiOperation("修改密码")
    @RequestMapping("/changep")
    @Aop(module = "用户模块",operator = "用户修改密码")
    public Result ChangeP(String Name,String Password)
    {
        return userService.ChangeP(Name,Password);
    }

}
