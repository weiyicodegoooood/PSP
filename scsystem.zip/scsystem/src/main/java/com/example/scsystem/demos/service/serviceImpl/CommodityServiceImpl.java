package com.example.scsystem.demos.service.serviceImpl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.scsystem.demos.Utils.Result;
import com.example.scsystem.demos.domin.Commodity;
import com.example.scsystem.demos.mapper.CommodityMapper;
import com.example.scsystem.demos.service.CommodityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommodityServiceImpl extends ServiceImpl<CommodityMapper, Commodity> implements CommodityService {


    @Autowired
    private CommodityMapper commodityMapper;

    @Override
    public List<Commodity> GetAllComs() {
       return commodityMapper.selectList(null);
    }

    @Override
    public Result Jiaru(Integer id) {

        LambdaQueryWrapper<Commodity> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Commodity::getId,id);
        Commodity commodity = commodityMapper.selectById(id);
        commodity.setState("1");
        commodityMapper.update(commodity,queryWrapper);
        return Result.success(commodity);
    }

    @Override
    public List<Commodity> GetAllCars() {

        LambdaQueryWrapper<Commodity> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Commodity::getState,"1");
        return commodityMapper.selectList(queryWrapper);
    }

    @Override
    public Result ShanChu(Integer id) {
        LambdaQueryWrapper<Commodity> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Commodity::getId,id);
        Commodity commodity = new Commodity();
        commodity.setState("0");
        commodityMapper.update(commodity,queryWrapper);
        return Result.success(commodity);
    }

    @Override
    public Result GetByName(String name) {
        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.like("Cname",name);

        List<Commodity> commodities = commodityMapper.selectList(queryWrapper);

        return Result.success(commodities);
    }

    @Override
    public Integer Sum(String state) {
        LambdaQueryWrapper<Commodity> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Commodity::getState,state);
        List<Commodity> commodities = commodityMapper.selectList(queryWrapper);
        Integer sum = 0;
        for(Commodity commodity : commodities)
        {
            String tmp = commodity.getPrice();
            Integer temp = Integer.parseInt(tmp);
            sum += temp;

        }
        return sum;
    }

    @Override
    public Result ClearCar(String state) {

        LambdaQueryWrapper<Commodity> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Commodity::getState,state);
        List<Commodity> commodities = commodityMapper.selectList(queryWrapper);
        for(Commodity commodity : commodities)
        {
            commodity.setState("0");
            commodityMapper.updateById(commodity);
        }
        return Result.success(null);
    }

    @Override
    public Result GetOne(Integer id) {
        LambdaQueryWrapper<Commodity> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Commodity::getId,id);
        Commodity commodity = commodityMapper.selectOne(queryWrapper);
        return Result.success(commodity);
    }
}
