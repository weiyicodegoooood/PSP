package com.example.scsystem.demos.controller;


import com.example.scsystem.demos.Aop.Aop;
import com.example.scsystem.demos.Utils.Result;
import com.example.scsystem.demos.domin.Commodity;
import com.example.scsystem.demos.service.CommodityService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "商品模块")
@Component
@RestController
@CrossOrigin
@ResponseBody
public class CommodityController {

    @Autowired
    private CommodityService commodityService;

    @ApiOperation("查看所有商品")
    @RequestMapping("/getallcoms")
    @Aop(module = "商品模块",operator = "查看所有商品")
    public Result GetAllComs()
    {
        List<Commodity> commodities = commodityService.GetAllComs();

        return Result.success(commodities);
    }

    @ApiOperation("加入购物车")
    @RequestMapping("/jrcar")
    @Aop(module = "商品模块",operator = "加入购物车")
    public Result Jiaru(Integer id)
    {
        return commodityService.Jiaru(id);
    }

    @ApiOperation("查看购物车中的商品")
    @RequestMapping("/getallcars")
    @Aop(module = "商品模块",operator = "查看购物车中的商品")
    public Result GetAllCars()
    {
        List<Commodity> commodityList = commodityService.GetAllCars();

        return Result.success(commodityList);
    }

    @ApiOperation("从购物车中移除")
    @RequestMapping("/sccar")
    @Aop(module = "商品模块",operator = "从购物车中移除")
    public Result Shanchu(Integer id)
    {
        return commodityService.ShanChu(id);
    }

    @ApiOperation("根据名字查找商品")
    @RequestMapping("/getby/{name}")
    @Aop(module = "商品模块",operator = "查找商品")
    public Result GetByName(@PathVariable String name)
    {
        return commodityService.GetByName(name);
    }


    @ApiOperation("计算总价")
    @RequestMapping("/getsum/{state}")
    @Aop(module = "商品模块",operator = "计算商品总价")
    public Integer Sum(@PathVariable String state)
    {
        return commodityService.Sum(state);
    }

    @ApiOperation("清空购物车")
    @RequestMapping("/clear/{state}")
    @Aop(module = "商品模块",operator = "清空购物车")
    public Result Clearcar(@PathVariable String state)
    {
        return commodityService.ClearCar(state);
    }

    @ApiOperation("查看具体商品")
    @RequestMapping("/getone")
    @Aop(module = "商品模块",operator = "查看具体商品")
    public Result GetOne(Integer id) {
        return commodityService.GetOne(id);
    }



}
