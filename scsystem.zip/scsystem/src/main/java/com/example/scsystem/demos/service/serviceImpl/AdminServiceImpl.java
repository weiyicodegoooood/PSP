package com.example.scsystem.demos.service.serviceImpl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.scsystem.demos.Utils.Result;
import com.example.scsystem.demos.domin.Admin;
import com.example.scsystem.demos.domin.Commodity;
import com.example.scsystem.demos.domin.User;
import com.example.scsystem.demos.mapper.AdminMapper;
import com.example.scsystem.demos.mapper.CommodityMapper;
import com.example.scsystem.demos.mapper.UserMapper;
import com.example.scsystem.demos.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AdminServiceImpl extends ServiceImpl<AdminMapper, Admin> implements AdminService {

    @Autowired
    private AdminMapper adminMapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private CommodityMapper commodityMapper;
    @Override
    public Result login(String Name, String Password) {
        LambdaQueryWrapper<Admin> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(Admin::getName,Name).eq(Admin::getPassword,Password);
        Admin admin = adminMapper.selectOne(lambdaQueryWrapper);
        return Result.success(admin);
    }

    @Override
    public Result GetByUser(String Name) {
        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.like("Uname",Name);
        List<Admin> admins = userMapper.selectList(queryWrapper);
        return Result.success(admins);
    }

    @Override
    public Result GetByCom(String name) {
        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.like("Cname",name);

        List<Commodity> list = commodityMapper.selectList(queryWrapper);
        return Result.success(list);
    }

    @Override
    public Result InsertUser(User user) {
        userMapper.insert(user);
        return Result.success(null);
    }

    @Override
    public Result InsertCom(Commodity commodity) {
        commodityMapper.insert(commodity);
        return Result.success(null);
    }

    @Override
    public Result DeleteUser(String Name) {
        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.eq("Uname",Name);
        userMapper.delete(queryWrapper);
        return Result.success(null);
    }

    @Override
    public Result DeleteCom(Integer id) {
        int delete = commodityMapper.deleteById(id);
        return Result.success(delete);
    }

    @Override
    public Result updateUser(int id,String password) {
//        UpdateWrapper<User> updateWrapper = Wrappers.update();
//        updateWrapper.eq("id",id);
//        User user = new User();
//        user.setPassword(password);
//        int update = userMapper.update(user,updateWrapper);
        int update = adminMapper.updatePwd(password, id);
        return Result.success(update);
    }

    @Override
    public List<User> GetAllUsers() {

        return userMapper.selectList(null);
    }

    @Override
    public List<Commodity> GetAllCom() {
        return commodityMapper.selectList(null);
    }


}
