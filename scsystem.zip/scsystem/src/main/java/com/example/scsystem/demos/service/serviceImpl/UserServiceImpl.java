package com.example.scsystem.demos.service.serviceImpl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.scsystem.demos.Utils.ErrorCode;
import com.example.scsystem.demos.Utils.Result;
import com.example.scsystem.demos.domin.User;
import com.example.scsystem.demos.mapper.UserMapper;
import com.example.scsystem.demos.service.UserService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public Result login(String Name, String Password) {

        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();

        queryWrapper.eq(User::getUname,Name).eq(User::getPassword,Password);

        User user = userMapper.selectOne(queryWrapper);
        return Result.success(user);
    }

    @Override
    public Result register(User user) {
        String name = user.getUname();
        String password = user.getPassword();

        if(StringUtils.isBlank(name) || StringUtils.isBlank(password))
        {
            return Result.Fail(ErrorCode.PARAMS_ERROR.getCode(), ErrorCode.PARAMS_ERROR.getMsg());
        }
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getUname,name);
        User user1 = userMapper.selectOne(queryWrapper);

        if(user1 != null){
            return Result.Fail(ErrorCode.ACCOUNT_EXIST.getCode(), "账号已被注册");
        }

        User user2 = new User();
        user2.setUname(name).setPassword(password);
        userMapper.insert(user2);
        return Result.success(null);
    }

    @Override
    public Result logout(HttpServletRequest req) {
        User user = (User)req.getSession().getAttribute("user");
        if(user != null)
        {
            req.getSession().invalidate();;
        }
        return Result.success(null);
    }

    @Override
    public Result ChangeP(String Name,String Password) {

        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getUname,Name);
        User user = new User();
        user.setPassword(Password);
        userMapper.update(user,queryWrapper);
        return Result.success(null);
    }
}
