package com.example.scsystem.demos.domin;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.springframework.stereotype.Component;

@Data
@NoArgsConstructor  //空参构造方法
@AllArgsConstructor //全参构造方法
@Component
@Accessors(chain = true)
@TableName("user")
@ApiModel(value = "user对象",description = "用户信息")
public class User {
    @TableField(value = "id")
    @ApiModelProperty(value = "用户id")
    private Integer id;

    @TableField(value = "Uname")
    @ApiModelProperty(value = "用户账号")
    private String uname;

    @TableField(value = "Password")
    @ApiModelProperty(value = "用户密码")
    private String password;

    @TableField(value = "Sex")
    @ApiModelProperty(value = "用户性别")
    private String sex;

    @TableField(value = "Tx")
    @ApiModelProperty(value = "用户头像信息")
    private String tx;

    @TableField(value = "Age")
    @ApiModelProperty(value = "用户年龄")
    private Integer age;

    @TableField(value = "Address")
    @ApiModelProperty(value = "用户地址")
    private String address;
}
