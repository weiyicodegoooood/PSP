package com.example.scsystem.demos.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.example.scsystem.demos.Utils.Result;
import com.example.scsystem.demos.domin.Commodity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public interface CommodityService extends IService<Commodity> {

    List<Commodity> GetAllComs();

    Result Jiaru(Integer id);


    List<Commodity> GetAllCars();

    Result ShanChu(Integer id);

    Result GetByName(String name);

    Integer Sum(String state);

    Result ClearCar(String state);

    Result GetOne(Integer id);




}
