package com.example.scsystem.demos.domin;


import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.springframework.stereotype.Component;

@Data
@NoArgsConstructor  //空参构造方法
@AllArgsConstructor //全参构造方法
@Component
@Accessors(chain = true)
@TableName("admin")
@ApiModel(value = "admin对象",description = "管理员信息")
public class Admin {

    @TableField(value = "Aname")
    @ApiModelProperty(value = "管理员用户名")
    private String name;

    @TableField(value = "Apassword")
    @ApiModelProperty(value = "管理员密码")
    private String password;
}
