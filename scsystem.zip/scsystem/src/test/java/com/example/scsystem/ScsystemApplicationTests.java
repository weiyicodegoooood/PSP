package com.example.scsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScsystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
